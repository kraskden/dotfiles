import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_CLASS;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.openMocks;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;

#parse("File Header.java")
@TestInstance(PER_CLASS)
class ${NAME} {

    @BeforeAll
    void initAll() {
        openMocks(this);
    }

  ${BODY}
}